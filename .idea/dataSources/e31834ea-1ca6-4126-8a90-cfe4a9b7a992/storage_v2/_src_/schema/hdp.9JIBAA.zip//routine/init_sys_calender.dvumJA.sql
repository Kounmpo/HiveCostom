create
    definer = root@`%` procedure init_sys_calender(IN start_date date, IN end_date date)
BEGIN
    DECLARE
        i INT DEFAULT 0;
    DECLARE
        date_count INT;

    IF start_date IS NULL THEN
        SET start_date = MAKEDATE('1970', 1);
    END IF;
    IF end_date IS NULL THEN
        SET end_date = MAKEDATE('2050', 1);
    END IF;

    SET date_count = DATEDIFF(end_date, start_date);

    WHILE
        i < date_count
        DO
            INSERT INTO sys_calender (dt, dt2, yr, year_num, mm, dd, dayofweek, week_num, month_num, dayofmonth,
                                      dayofyear, qr, bourse_week, yrmm, yr_mm, week_begin, week_end)
            SELECT start_date                                                 dt,
                   DATE_FORMAT(start_date, '%Y%m%d')                          dt2,
                   DATE_FORMAT(start_date, '%Y')                              yr,
                   YEAR(start_date)                                           year_num,
                   DATE_FORMAT(start_date, '%m')                              mm,
                   DATE_FORMAT(start_date, '%d')                              dd,
                   CASE DAYOFWEEK(start_date)
                       WHEN 1 THEN '星期日'
                       WHEN 2 THEN '星期一'
                       WHEN 3 THEN '星期二'
                       WHEN 4 THEN '星期三'
                       WHEN 5 THEN '星期四'
                       WHEN 6 THEN '星期五'
                       WHEN 7 THEN '星期六' END                                  dayofweek,
                   DATE_FORMAT(start_date, '%u')                              week_num,
                   MONTH(start_date)                                          month_num,
                   DAYOFMONTH(start_date)                                     dayofmonth,
                   DAYOFYEAR(start_date)                                      dayofyear,
                   CONCAT(DATE_FORMAT(start_date, '%Y'), QUARTER(start_date)) qr,
                   DATE_FORMAT(start_date, '%Y-%u')                           bourse_week,
                   DATE_FORMAT(start_date, '%Y%m')                            yrmm,
                   DATE_FORMAT(start_date, '%Y-%m')                           yr_mm,
                   DATE_FORMAT(SUBDATE(start_date,
                                       IF(DATE_FORMAT(start_date, '%w') = 0, 7, DATE_FORMAT(start_date, '%w')) - 1),
                               '%Y%m%d')                                      week_begin,

                   DATE_FORMAT(SUBDATE(start_date,
                                       IF(DATE_FORMAT(start_date, '%w') = 0, 7, DATE_FORMAT(start_date, '%w')) - 1 - 6),
                               '%Y%m%d')                                      week_end
            FROM dual
            ON DUPLICATE KEY UPDATE dt=VALUES(dt),
                                    dt2=VALUES(dt2),
                                    yr=VALUES(yr),
                                    year_num=VALUES(year_num),
                                    mm=VALUES(mm),
                                    dd=VALUES(dd),
                                    dayofweek=VALUES(dayofweek),
                                    week_num=VALUES(week_num),
                                    month_num=VALUES(month_num),
                                    dayofmonth=VALUES(dayofmonth),
                                    dayofyear=VALUES(dayofyear),
                                    qr=VALUES(qr),
                                    bourse_week=VALUES(bourse_week),
                                    yrmm=VALUES(yrmm),
                                    yr_mm=VALUES(yr_mm),
                                    week_begin=VALUES(week_begin),
                                    week_end=VALUES(week_end);
            SET
                i = i + 1;
            SET start_date = DATE_ADD(start_date, INTERVAL 1 DAY);
        END WHILE;
END;

