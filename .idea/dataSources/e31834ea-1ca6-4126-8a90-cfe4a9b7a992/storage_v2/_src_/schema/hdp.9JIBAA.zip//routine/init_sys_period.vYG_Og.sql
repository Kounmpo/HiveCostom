create
    definer = root@`%` procedure init_sys_period(IN start_date date, IN end_date date)
BEGIN
    IF start_date IS NULL THEN
        SET start_date = MAKEDATE('1970', 1);
    END IF;
    IF end_date IS NULL THEN
        SET end_date = MAKEDATE('2050', 1);
    END IF;

    WHILE
        start_date < end_date
        DO
            INSERT INTO sys_period (yr, year_num, mm, month_num, yrmm, yr_mm)
            SELECT DATE_FORMAT(start_date, '%Y')    yr,
                   YEAR(start_date)                 year_num,
                   DATE_FORMAT(start_date, '%m')    mm,
                   MONTH(start_date)                month_num,
                   DATE_FORMAT(start_date, '%Y%m')  yrmm,
                   DATE_FORMAT(start_date, '%Y-%m') yr_mm
            FROM dual
            ON DUPLICATE KEY UPDATE yr=VALUES(yr),
                                    year_num=VALUES(year_num),
                                    mm=VALUES(mm),
                                    month_num=VALUES(month_num),
                                    yrmm=VALUES(yrmm),
                                    yr_mm=VALUES(yr_mm);
            SET start_date = DATE_ADD(start_date, INTERVAL 1 MONTH);
        END WHILE;
END;

