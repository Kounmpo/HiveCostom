create
    definer = root@`%` procedure po_contract_re_calc()
BEGIN
    DECLARE hasNext INT DEFAULT TRUE;
    DECLARE contractId BIGINT;
    DECLARE affected_contracts INT DEFAULT 0;
    DECLARE contractCur CURSOR FOR SELECT contract_id FROM po_frame_contract;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET hasNext = FALSE;

    OPEN contractCur;
    FETCH contractCur INTO contractId;

    WHILE hasNext
        DO
            SET affected_contracts = affected_contracts + 1;
            UPDATE po_frame_contract pfc
                CROSS JOIN
                (SELECT IFNULL(SUM(pri.request_amount), 0) total_request_amount,
                        IFNULL(SUM(pri.predis_amount), 0)  total_predis_amount
                 FROM po_request pri
                 WHERE pri.contract_id = contractId) pr
                CROSS JOIN
                (SELECT IFNULL(SUM(poi.order_amount), 0) total_order_amount
                 FROM po_request pri
                          JOIN po_order poi
                               ON poi.po_request_id = pri.po_request_id
                 WHERE pri.contract_id = contractId) po
            SET pfc.request_total_amount  = pr.total_request_amount,
                pfc.request_ratio         = IF(pfc.max_amount != 0, pr.total_request_amount / pfc.max_amount, 0),
                pfc.predis_surplus        = pfc.max_amount - pr.total_predis_amount,
                pfc.order_total_amount    = po.total_order_amount,
                pfc.order_release_rate    = IF(pfc.max_amount != 0, po.total_order_amount / pfc.max_amount, 0),
                pfc.actual_surplus        = pfc.max_amount - po.total_order_amount,
                pfc.object_version_number = pfc.object_version_number + 1
            WHERE pfc.contract_id = contractId;
            FETCH contractCur INTO contractId;
        END WHILE;
    CLOSE contractCur;
    SELECT affected_contracts;
END;

