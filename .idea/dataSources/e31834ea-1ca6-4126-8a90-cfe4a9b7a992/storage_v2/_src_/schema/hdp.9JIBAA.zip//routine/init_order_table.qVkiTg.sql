create
    definer = root@`%` procedure init_order_table(IN start bigint, IN end bigint)
BEGIN
    DECLARE num BIGINT DEFAULT start;
    WHILE num < end + 1
        DO
        INSERT INTO split_order_table VALUES(num);
        SET num = num + 1;
        END WHILE;
END;

